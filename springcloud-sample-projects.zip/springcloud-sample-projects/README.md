# Spring Cloud 示例工程

该示例工程包含以下几个部分:

* Eureka示例工程;


Spring Cloud Release Trains: [Dalston.SR1](http://projects.spring.io/spring-cloud/) 