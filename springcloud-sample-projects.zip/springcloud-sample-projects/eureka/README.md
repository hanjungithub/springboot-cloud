# TwoStepsFromJava-Cloud-Eureka

Spring Cloud 示例项目：服务治理Eureka服务器搭建。


Spring Cloud Release Trains: [Dalston SR1](http://projects.spring.io/spring-cloud/) 